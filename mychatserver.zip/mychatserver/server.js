const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

let messages = [];

// send message
app.post('/send', (req, res) => {
  const { to, msg } = req.body;
  messages.push({ to, msg });
  res.json({ success: true });
});

// receive messages
app.get('/receive/:to', (req, res) => {
  const { to } = req.params;
  const userMessages = messages.filter(m => m.to === to);
  messages = messages.filter(m => m.to !== to);
  res.json(userMessages);
});

app.get('/', (req, res) => {
  res.send('Server is running!');
});

app.listen(3000, () => console.log('Server running on port 3000'));